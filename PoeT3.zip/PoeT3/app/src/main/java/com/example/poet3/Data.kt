package com.example.poet3

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class Data : AppCompatActivity() {

    //variables

    // class Dataset : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var nameEditText: EditText
    private lateinit var startDateButton: Button
    private lateinit var startTimeButton: Button
    private lateinit var endDateButton: Button
    private lateinit var endTimeButton: Button
    private lateinit var descriptionEditText: EditText
    private lateinit var imageView: ImageView
    private lateinit var captureImageButton: Button
    private lateinit var submitButton: Button
    private val values = mutableListOf<String>()
    private var capturedImage: Bitmap? = null
    private lateinit var categorySpinner: Spinner
    private val defaultCategoryIndex = 0 // Declare the variable for the default category index

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 1
        private const val PERMISSION_REQUEST_CODE = 2
    }

    private var startDate: Date? = null
    private var startTime: Date? = null
    private var endDate: Date? = null
    private var endTime: Date? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data)
        listView = findViewById(R.id.listView)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, values)
        listView.adapter = adapter
        nameEditText = findViewById(R.id.nameEditText)
        startDateButton = findViewById(R.id.startDateButton)
        startTimeButton = findViewById(R.id.startTimeButton)
        endDateButton = findViewById(R.id.endDateButton)
        endTimeButton = findViewById(R.id.endTimeButton)
        descriptionEditText = findViewById(R.id.descriptionEditText)
        submitButton = findViewById(R.id.submitButton)
        startDateButton.setOnClickListener { showDatePicker(startDateListener) }
        startTimeButton.setOnClickListener { showTimePicker(startTimeListener) }
        endDateButton.setOnClickListener { showDatePicker(endDateListener) }
        endTimeButton.setOnClickListener { showTimePicker(endTimeListener) }
        submitButton.setOnClickListener { captureValues() }
        categorySpinner = findViewById(R.id.categorySpinner)

        val categories = listOf("Work Projects", "Personal Activities", "Study Subjects")
        //Replace with your desired categories
        val categoryAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item, categories
        )
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = categoryAdapter
        categorySpinner.setSelection(defaultCategoryIndex)
        // Set the default selection using the variable

    }
    private fun showDatePicker(dateSetListener: DatePickerDialog.OnDateSetListener) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(
            this, dateSetListener, year, month,
            day
        )
        datePickerDialog.show()
    }

    private fun showTimePicker(timeSetListener: TimePickerDialog.OnTimeSetListener) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val timePickerDialog = TimePickerDialog(
            this, timeSetListener, hour,
            minute, true
        )
        timePickerDialog.show()
    }
    private val startDateListener = DatePickerDialog.OnDateSetListener { _:
                                                                         DatePicker, year: Int, month: Int, day: Int ->
        val selectedCalendar = Calendar.getInstance()
        selectedCalendar.set(year, month, day)
        startDate = selectedCalendar.time
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val selectedDateString = dateFormat.format(startDate!!)
        startDateButton.text = selectedDateString
    }
    private val startTimeListener = TimePickerDialog.OnTimeSetListener { _:
                                                                         TimePicker, hourOfDay: Int, minute: Int ->
        val selectedCalendar = Calendar.getInstance()
        selectedCalendar.time = startDate
        selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
        selectedCalendar.set(Calendar.MINUTE, minute)
        startTime = selectedCalendar.time
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val selectedTimeString = timeFormat.format(startTime!!)
        startTimeButton.text = selectedTimeString
    }
    private val endDateListener = DatePickerDialog.OnDateSetListener { _:
                                                                       DatePicker, year: Int, month: Int, day: Int ->
        val selectedCalendar = Calendar.getInstance()
        selectedCalendar.set(year, month, day)
        endDate = selectedCalendar.time
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val selectedDateString = dateFormat.format(endDate!!)
        endDateButton.text = selectedDateString
    }
    private val endTimeListener = TimePickerDialog.OnTimeSetListener { _:
                                                                       TimePicker, hourOfDay: Int, minute: Int ->
        val selectedCalendar = Calendar.getInstance()
        selectedCalendar.time = endDate
        selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
        selectedCalendar.set(Calendar.MINUTE, minute)
        endTime = selectedCalendar.time
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val selectedTimeString = timeFormat.format(endTime!!)
        endTimeButton.text = selectedTimeString
    }

    private fun captureValues() {
        val name = nameEditText.text.toString()
        val description = descriptionEditText.text.toString()
        val category = categorySpinner.selectedItem.toString()
        // Retrieve the
        //selected category
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val startDateString = startDateButton.text.toString()
        val startTimeString = startTimeButton.text.toString()
        val endDateString = endDateButton.text.toString()
        val endTimeString = endTimeButton.text.toString()
        var startDate: Date? = null
        var startTime: Date? = null
        var endDate: Date? = null
        var endTime: Date? = null
        try {
            startDate = dateFormat.parse(startDateString)
            startTime = timeFormat.parse(startTimeString)
            endDate = dateFormat.parse(endDateString)
            endTime = timeFormat.parse(endTimeString)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        values.clear()
        values.add("Name: $name")
        values.add("Category: $category") // Add the category to the captured
        values
        if (startDate != null && startTime != null && endDate != null && endTime !=
            null
        ) {
            values.add("Start Date: ${dateFormat.format(startDate)}")
            values.add("Start Time: ${timeFormat.format(startTime)}")
            values.add("End Date: ${dateFormat.format(endDate)}")
            values.add("End Time: ${timeFormat.format(endTime)}")
        }
        values.add("Description: $description")
        adapter.notifyDataSetChanged()
        // Clear the input fields
        nameEditText.text.clear()
        categorySpinner.setSelection(0) // Reset the category selection
        startDateButton.text = getString(R.string.select_date)
        startTimeButton.text = getString(R.string.select_time)
        endDateButton.text = getString(R.string.select_date)
        endTimeButton.text = getString(R.string.select_time)
        descriptionEditText.text.clear()
    }

}