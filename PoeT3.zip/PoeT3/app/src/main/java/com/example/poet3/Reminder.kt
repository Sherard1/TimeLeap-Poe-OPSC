package com.example.poet3

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.util.ArrayList

class Reminder : AppCompatActivity() {

    private lateinit var editTextReminder: EditText
    private lateinit var buttonAddReminder: Button
    private lateinit var buttonDelete: Button
    private lateinit var textViewReminders: TextView
    private lateinit var listViewReminders: ListView

    private lateinit var reminders: ArrayList<String>
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var selectedReminders: ArrayList<Int>


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminder)

        // Initialize views
        editTextReminder = findViewById(R.id.editTextReminder)
        buttonAddReminder = findViewById(R.id.buttonAddReminder)
        buttonDelete = findViewById(R.id.buttonDelete)
        textViewReminders = findViewById(R.id.textViewReminders)
        listViewReminders = findViewById(R.id.listViewReminders)

        // Initialize reminders list and adapter
        reminders = ArrayList()
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, reminders)
        listViewReminders.adapter = adapter
        listViewReminders.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        // Initialize selected reminders list
        selectedReminders = ArrayList()

        // Add reminder button click listener
        buttonAddReminder.setOnClickListener {
            val reminderText = editTextReminder.text.toString().trim()
            if (reminderText.isNotEmpty()) {
                addReminder(reminderText)
                editTextReminder.text.clear()
            }
        }

        // Set item click listener for selecting/deselecting a reminder
        listViewReminders.setOnItemClickListener { _, _, position, _ ->
            if (selectedReminders.contains(position)) {
                selectedReminders.remove(position)
            } else {
                selectedReminders.add(position)
            }
        }

        // Delete button click listener
        buttonDelete.setOnClickListener {
            deleteSelectedReminders()
        }
    }

    private fun addReminder(reminderText: String) {
        reminders.add(reminderText)
        adapter.notifyDataSetChanged()
    }

    private fun deleteSelectedReminders() {
        val iterator = selectedReminders.iterator()
        while (iterator.hasNext()) {
            val position = iterator.next()
            reminders.removeAt(position)
            iterator.remove()
        }
        adapter.notifyDataSetChanged()
        listViewReminders.clearChoices()
    }
}
