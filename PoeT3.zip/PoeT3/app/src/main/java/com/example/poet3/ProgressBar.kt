package com.example.poet3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast

class ProgressBar : AppCompatActivity() {

    private lateinit var editTextGoal: EditText
    private lateinit var editTextProgress: EditText
    private lateinit var editTextDescription: EditText
    private lateinit var progressBar: ProgressBar

    private var goal: Int = 0
    private var progress: Int = 0
    private var description: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress_bar)

        editTextGoal = findViewById(R.id.editTextGoal)
        editTextProgress = findViewById(R.id.editTextProgress)
        editTextDescription = findViewById(R.id.editTextDescription)
        progressBar = findViewById(R.id.progressBar)

        val buttonSetGoal: Button = findViewById(R.id.buttonSetGoal)
        buttonSetGoal.setOnClickListener {
            setGoal()
        }

        val buttonUpdateProgress: Button = findViewById(R.id.buttonUpdateProgress)
        buttonUpdateProgress.setOnClickListener {
            updateProgress()
        }
    }

    private fun setGoal() {
        val goalText = editTextGoal.text.toString()
        val descriptionText = editTextDescription.text.toString()
        if (goalText.isNotEmpty() && descriptionText.isNotEmpty()) {
            goal = goalText.toInt()
            description = descriptionText
            Toast.makeText(this, "Goal set: $goal hours", Toast.LENGTH_SHORT).show()
            progressBar.max = goal
        } else {
            Toast.makeText(this, "Please enter a valid goal and description", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateProgress() {
        val progressText = editTextProgress.text.toString()
        if (progressText.isNotEmpty()) {
            progress = progressText.toInt()
            progressBar.progress = progress
            Toast.makeText(this, "Progress updated: $progress hours", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Please enter a valid progress", Toast.LENGTH_SHORT).show()
        }
    }
}

